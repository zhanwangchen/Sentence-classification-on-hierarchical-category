#!/usr/bin/python
# -*- coding: utf-8 -*-
# Example classifier, which does a random prediction.
# Author: Jan Saputra Mueller

import csv
import sys
import os
import numpy
import random

def predict_question_category(qfile = 'questions.csv'):
  # open questions file
  file_question = open(qfile, 'r')
  reader_question = csv.reader(file_question, delimiter=',', quotechar='"', escapechar='\\', doublequote=False)
  next(reader_question) # first line contains the column names
  n_questions = 0 # number of questions
  for line in reader_question: # count number of questions
    n_questions += 1
  file_question.close()

  # read table category
  file_category = open('category.csv', 'r')
  reader_category = csv.reader(file_category, delimiter=',', quotechar='"', escapechar='\\', doublequote=False)
  major_categories = []
  minor_categories = []
  next(reader_category) # skip first line
  for line in reader_category:
    if line[1] == '0':
      # category is a major category
      major_categories.append(int(line[0]))
    else:
      # category is a minor category
      minor_categories.append(int(line[0]))
  file_category.close()

  # make random predictions
  predictions = []
  for i in range(n_questions):
    d = {}
    d['major_category'] = random.choice(major_categories)
    d['minor_category'] = random.choice(minor_categories)
    d['confidence_major_cat'] = random.random()
    d['confidence_minor_cat'] = random.random()
    predictions.append(d)

  return predictions
